(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_d1d9a92a._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_ad390bcb._.js"
],
    source: "dynamic"
});
