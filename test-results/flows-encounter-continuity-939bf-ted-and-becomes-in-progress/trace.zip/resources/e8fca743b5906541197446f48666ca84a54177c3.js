(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/breadcrumbs/breadcrumbs.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildBreadcrumbs",
    ()=>buildBreadcrumbs
]);
function buildBreadcrumbs(pathname, patientName) {
    const segments = pathname.split("/").filter(Boolean);
    const base = {
        label: "Pacientes",
        href: "/patients",
        current: false
    };
    // Exact list view
    if (pathname === "/patients") {
        return [
            {
                label: "Pacientes",
                current: true
            }
        ];
    }
    const crumbs = [
        base
    ];
    // /patients/{id}
    const patientId = segments[1];
    if (patientId) {
        const patientCrumb = {
            label: patientName ?? "Paciente",
            href: `/patients/${patientId}`,
            current: false
        };
        // If this is the last segment, it is current.
        if (segments.length === 2) {
            patientCrumb.current = true;
            // current crumb must not have an href
            patientCrumb.href = undefined;
        }
        crumbs.push(patientCrumb);
    }
    // /patients/{id}/{sub}
    const thirdSegment = segments[2];
    if (thirdSegment) {
        const label = (()=>{
            switch(thirdSegment){
                case "encounters":
                    return "Encuentros";
                case "vital-signs":
                    return "Signos vitales";
                case "assessments":
                    return "Evaluaciones";
                default:
                    return `${thirdSegment.charAt(0).toUpperCase()}${thirdSegment.slice(1)}`;
            }
        })();
        crumbs.push({
            label,
            current: true
        });
    }
    return crumbs;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/Breadcrumbs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Breadcrumbs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$breadcrumbs$2f$breadcrumbs$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/breadcrumbs/breadcrumbs.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function Breadcrumbs({ patientName }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const crumbs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$breadcrumbs$2f$breadcrumbs$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildBreadcrumbs"])(pathname, patientName);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        "aria-label": "Navegación de ubicación",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
            role: "list",
            className: "flex items-center gap-1 text-sm flex-wrap",
            children: crumbs.map((crumb, index)=>{
                const isLast = index === crumbs.length - 1;
                const content = crumb.href && !crumb.current ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: crumb.href,
                    className: "text-muted hover:text-foreground transition-colors",
                    children: crumb.label
                }, void 0, false, {
                    fileName: "[project]/app/components/Breadcrumbs.tsx",
                    lineNumber: 28,
                    columnNumber: 15
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-foreground font-medium",
                    "aria-current": crumb.current ? "page" : undefined,
                    children: crumb.label
                }, void 0, false, {
                    fileName: "[project]/app/components/Breadcrumbs.tsx",
                    lineNumber: 35,
                    columnNumber: 15
                }, this);
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    className: "flex items-center gap-1",
                    children: [
                        content,
                        !isLast ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "aria-hidden": "true",
                            className: "text-muted select-none",
                            children: "›"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Breadcrumbs.tsx",
                            lineNumber: 50,
                            columnNumber: 17
                        }, this) : null
                    ]
                }, `${crumb.label}-${index}`, true, {
                    fileName: "[project]/app/components/Breadcrumbs.tsx",
                    lineNumber: 44,
                    columnNumber: 13
                }, this);
            })
        }, void 0, false, {
            fileName: "[project]/app/components/Breadcrumbs.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/Breadcrumbs.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_s(Breadcrumbs, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = Breadcrumbs;
var _c;
__turbopack_context__.k.register(_c, "Breadcrumbs");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/patients/[id]/components/assessments/BarthelCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BarthelCard",
    ()=>BarthelCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const ACTIVITY_LABELS = {
    feeding: "Alimentación",
    bathing: "Baño",
    grooming: "Higiene personal",
    dressing: "Vestido",
    bowel: "Control intestinal",
    bladder: "Control vesical",
    toilet: "Uso del baño",
    transfer: "Transferencias",
    mobility: "Deambulación",
    stairs: "Escaleras"
};
function getBarthelLevelBadge(level) {
    switch(level){
        case "independent":
            return {
                label: "Independiente",
                className: "bg-badge-success-bg text-badge-success-text"
            };
        case "mild-dependency":
            return {
                label: "Dep. Leve",
                className: "bg-badge-info-bg text-badge-info-text"
            };
        case "moderate-dependency":
            return {
                label: "Dep. Moderada",
                className: "bg-badge-warning-bg text-badge-warning-text"
            };
        case "severe-dependency":
            return {
                label: "Dep. Severa",
                className: "bg-badge-orange-bg text-badge-orange-text"
            };
        case "total-dependency":
            return {
                label: "Dep. Total",
                className: "bg-badge-error-bg text-badge-error-text"
            };
    }
    // `level` is a discriminated union; this should never be reached.
    const _exhaustiveCheck = level;
    void _exhaustiveCheck;
    return {
        label: "Desconocido",
        className: "bg-badge-neutral-bg text-badge-neutral-text"
    };
}
function BarthelCard({ assessment }) {
    _s();
    const badge = getBarthelLevelBadge(assessment.functionalLevel);
    const [expanded, setExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "border border-border rounded-lg p-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs font-semibold uppercase tracking-wide text-muted",
                        children: "Índice de Barthel"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm font-semibold text-foreground",
                        children: [
                            assessment.totalScore,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs text-muted",
                                children: " / 100"
                            }, void 0, false, {
                                fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                                lineNumber: 80,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 justify-end flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.className}`,
                                children: badge.label
                            }, void 0, false, {
                                fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                                lineNumber: 83,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "inline-flex items-center gap-1 text-xs text-primary hover:underline",
                                onClick: ()=>setExpanded((v)=>!v),
                                "aria-expanded": expanded,
                                "aria-label": expanded ? "Ocultar detalle" : "Ver detalle",
                                children: expanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "Ocultar",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                            size: 14,
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                                            lineNumber: 98,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "Ver",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                            size: 14,
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                                            lineNumber: 103,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true)
                            }, void 0, false, {
                                fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                                lineNumber: 88,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                        lineNumber: 82,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            expanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-2xl font-bold text-foreground",
                        children: assessment.totalScore
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                        lineNumber: 112,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs text-muted",
                        children: "puntos"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                        lineNumber: 115,
                        columnNumber: 11
                    }, this),
                    assessment.items.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
                            className: "grid grid-cols-2 gap-x-4 gap-y-2 text-xs",
                            children: assessment.items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                            className: "text-muted",
                                            children: ACTIVITY_LABELS[item.activity]
                                        }, void 0, false, {
                                            fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                                            lineNumber: 127,
                                            columnNumber: 23
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                            className: "text-foreground",
                                            children: [
                                                item.score,
                                                " / ",
                                                item.maxScore
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                                            lineNumber: 130,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, item.activity, true, {
                                    fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                                    lineNumber: 126,
                                    columnNumber: 21
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                            lineNumber: 119,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                        lineNumber: 118,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
                lineNumber: 111,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/patients/[id]/components/assessments/BarthelCard.tsx",
        lineNumber: 73,
        columnNumber: 5
    }, this);
}
_s(BarthelCard, "DuL5jiiQQFgbn7gBKAyxwS/H4Ek=");
_c = BarthelCard;
var _c;
__turbopack_context__.k.register(_c, "BarthelCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/patients/[id]/components/assessments/EcogCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EcogCard",
    ()=>EcogCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const PERFORMANCE_LEVEL_LABELS = {
    "fully-active": {
        label: "Actividad normal",
        description: "Totalmente activo, sin restricciones en actividades habituales."
    },
    restricted: {
        label: "Síntomas leves",
        description: "Puede realizar actividades livianas pero tiene alguna limitación para esfuerzos intensos."
    },
    ambulatory: {
        label: "Ambulatorio, no puede trabajar",
        description: "Puede levantarse y cuidarse solo, pero no puede realizar trabajo activo."
    },
    "limited-self-care": {
        label: "Limitado, pasa mucho tiempo en cama",
        description: "Solo puede cuidarse parcialmente. Permanece en cama más del 50% del día."
    },
    disabled: {
        label: "Totalmente dependiente",
        description: "Incapaz de cuidarse. Permanece completamente en cama."
    }
};
function getEcogLevelBadge(level) {
    switch(level){
        case "fully-active":
            return {
                label: PERFORMANCE_LEVEL_LABELS[level].label,
                className: "bg-green-100 text-green-800"
            };
        case "restricted":
            return {
                label: PERFORMANCE_LEVEL_LABELS[level].label,
                className: "bg-blue-100 text-blue-800"
            };
        case "ambulatory":
            return {
                label: PERFORMANCE_LEVEL_LABELS[level].label,
                className: "bg-yellow-100 text-yellow-800"
            };
        case "limited-self-care":
            return {
                label: PERFORMANCE_LEVEL_LABELS[level].label,
                className: "bg-orange-100 text-orange-800"
            };
        case "disabled":
            return {
                label: PERFORMANCE_LEVEL_LABELS[level].label,
                className: "bg-red-100 text-red-800"
            };
    }
    const _exhaustiveCheck = level;
    void _exhaustiveCheck;
    return {
        label: "Desconocido",
        className: "bg-surface text-muted border border-border"
    };
}
function EcogCard({ assessment }) {
    _s();
    const [expanded, setExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const badge = getEcogLevelBadge(assessment.performanceLevel);
    const levelInfo = PERFORMANCE_LEVEL_LABELS[assessment.performanceLevel];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "border border-border rounded-lg p-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs font-semibold uppercase tracking-wide text-muted",
                        children: "ECOG"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm font-semibold text-foreground",
                        children: assessment.score
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-1 justify-end items-center gap-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "inline-flex items-center gap-1 text-xs text-primary hover:underline",
                            onClick: ()=>setExpanded((v)=>!v),
                            "aria-expanded": expanded,
                            "aria-label": expanded ? "Ocultar detalle" : "Ver detalle",
                            children: expanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    "Ocultar",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                        size: 14,
                                        "aria-hidden": "true"
                                    }, void 0, false, {
                                        fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
                                        lineNumber: 108,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    "Ver",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                        size: 14,
                                        "aria-hidden": "true"
                                    }, void 0, false, {
                                        fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
                                        lineNumber: 113,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true)
                        }, void 0, false, {
                            fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
                            lineNumber: 98,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this),
            expanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.className}`,
                        children: badge.label
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
                        lineNumber: 122,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-muted mt-2",
                        children: levelInfo.description
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
                        lineNumber: 127,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
                lineNumber: 121,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/patients/[id]/components/assessments/EcogCard.tsx",
        lineNumber: 89,
        columnNumber: 5
    }, this);
}
_s(EcogCard, "DuL5jiiQQFgbn7gBKAyxwS/H4Ek=");
_c = EcogCard;
var _c;
__turbopack_context__.k.register(_c, "EcogCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/patients/[id]/components/assessments/NecpalCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NecpalCard",
    ()=>NecpalCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function getNecpalResultBadge(result) {
    switch(result){
        case "positive":
            return {
                label: "NECPAL +",
                className: "bg-surface text-error border border-error"
            };
        case "negative":
            return {
                label: "NECPAL −",
                className: "bg-surface text-success border border-success"
            };
    }
    const _exhaustiveCheck = result;
    void _exhaustiveCheck;
    return {
        label: "NECPAL",
        className: "bg-surface text-muted border border-border"
    };
}
const INDICATOR_LABELS = {
    demandIndicator: "Demanda — paciente/familia expresan necesidades",
    needIndicator: "Necesidad — síntomas no controlados o declive funcional",
    diseaseIndicator: "Enfermedad — indicadores específicos por patología"
};
function NecpalCard({ assessment }) {
    _s();
    const badge = getNecpalResultBadge(assessment.result);
    const [expanded, setExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "border border-border rounded-lg p-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs font-semibold uppercase tracking-wide text-muted",
                        children: "Cribado NECPAL"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-1 justify-end items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.className}`,
                                children: badge.label
                            }, void 0, false, {
                                fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                                lineNumber: 58,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "inline-flex items-center gap-1 text-xs text-primary hover:underline",
                                onClick: ()=>setExpanded((v)=>!v),
                                "aria-expanded": expanded,
                                "aria-label": expanded ? "Ocultar detalle" : "Ver detalle",
                                children: expanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "Ocultar",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                            size: 14,
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                                            lineNumber: 73,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        "Ver",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                            size: 14,
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                                            lineNumber: 78,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true)
                            }, void 0, false, {
                                fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            expanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs text-muted",
                        children: "Pregunta sorpresa"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                        lineNumber: 87,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: assessment.indicators.surpriseQuestion ? "text-foreground" : "text-error",
                        children: assessment.indicators.surpriseQuestion ? "Sí me sorprendería" : "No me sorprendería"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                        lineNumber: 88,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs text-muted italic mt-1",
                        children: "Una respuesta negativa activa el cribado NECPAL positivo"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                        lineNumber: 99,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2 space-y-1 text-xs",
                        children: Object.entries(INDICATOR_LABELS).map(([key, label])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: assessment.indicators[key] ? "text-success" : "text-muted",
                                    children: [
                                        assessment.indicators[key] ? "✓" : "○",
                                        " ",
                                        label
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                                    lineNumber: 106,
                                    columnNumber: 17
                                }, this)
                            }, key, false, {
                                fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                                lineNumber: 105,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                        lineNumber: 103,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
                lineNumber: 86,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/patients/[id]/components/assessments/NecpalCard.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_s(NecpalCard, "DuL5jiiQQFgbn7gBKAyxwS/H4Ek=");
_c = NecpalCard;
var _c;
__turbopack_context__.k.register(_c, "NecpalCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/date-time/date-time.utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "APP_TIME_ZONE",
    ()=>APP_TIME_ZONE,
    "composeLocalDateTimeToUtcIso",
    ()=>composeLocalDateTimeToUtcIso,
    "formatCalendarDateInTimeZone",
    ()=>formatCalendarDateInTimeZone,
    "hasTimeComponent",
    ()=>hasTimeComponent,
    "isDateOnly",
    ()=>isDateOnly,
    "isValidLocalTimeString",
    ()=>isValidLocalTimeString,
    "parsePlannedDateAndTime",
    ()=>parsePlannedDateAndTime
]);
const APP_TIME_ZONE = "America/Argentina/Buenos_Aires";
function isDateOnly(value) {
    if (!value) return false;
    return /^\d{4}-\d{2}-\d{2}$/.test(value);
}
function hasTimeComponent(value) {
    if (!value) return false;
    return value.includes("T");
}
function isValidLocalTimeString(value) {
    if (!value) return false;
    return /^([01]\d|2[0-3]):([0-5]\d)$/.test(value);
}
function formatCalendarDateInTimeZone(date, timeZone = APP_TIME_ZONE) {
    const parts = formatToPartsInTimeZone(date.getTime(), timeZone);
    const month = String(parts.month).padStart(2, "0");
    const day = String(parts.day).padStart(2, "0");
    return `${parts.year}-${month}-${day}`;
}
function parsePlannedDateAndTime(value, timeZone = APP_TIME_ZONE) {
    if (!value) return undefined;
    if (isDateOnly(value)) {
        return {
            plannedDate: value
        };
    }
    if (!hasTimeComponent(value)) return undefined;
    const datetimeMatch = value.match(/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})/);
    if (datetimeMatch) {
        return {
            plannedDate: datetimeMatch[1],
            plannedTime: datetimeMatch[2]
        };
    }
    // Fallback: try to parse using date object and app timezone as a best effort.
    const instant = new Date(value);
    if (isNaN(instant.getTime())) return undefined;
    const parts = formatToPartsInTimeZone(instant.getTime(), timeZone);
    const month = String(parts.month).padStart(2, "0");
    const day = String(parts.day).padStart(2, "0");
    const hour = String(parts.hour).padStart(2, "0");
    const minute = String(parts.minute).padStart(2, "0");
    return {
        plannedDate: `${parts.year}-${month}-${day}`,
        plannedTime: `${hour}:${minute}`
    };
}
function parseLocalDateTime(date, time) {
    const dateMatch = /^([0-9]{4})-([0-9]{2})-([0-9]{2})$/.exec(date);
    if (!dateMatch) {
        throw new Error(`Invalid date-only value: ${date}`);
    }
    if (!isValidLocalTimeString(time)) {
        throw new Error(`Invalid local time value: ${time}`);
    }
    const timeMatch = /^([0-9]{2}):([0-9]{2})$/.exec(time);
    if (!timeMatch) {
        throw new Error(`Invalid local time value: ${time}`);
    }
    const year = Number(dateMatch[1]);
    const month = Number(dateMatch[2]);
    const day = Number(dateMatch[3]);
    const hour = Number(timeMatch[1]);
    const minute = Number(timeMatch[2]);
    if (Number.isNaN(year) || Number.isNaN(month) || Number.isNaN(day) || Number.isNaN(hour) || Number.isNaN(minute)) {
        throw new Error(`Invalid date or time values: ${date} ${time}`);
    }
    return {
        year,
        month,
        day,
        hour,
        minute,
        second: 0
    };
}
function formatToPartsInTimeZone(utcMs, timeZone) {
    const dtf = new Intl.DateTimeFormat("en-US", {
        timeZone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hourCycle: "h23"
    });
    const parts = dtf.formatToParts(new Date(utcMs));
    const map = {};
    for (const item of parts){
        if (item.type === "year") map.year = Number(item.value);
        if (item.type === "month") map.month = Number(item.value);
        if (item.type === "day") map.day = Number(item.value);
        if (item.type === "hour") map.hour = Number(item.value);
        if (item.type === "minute") map.minute = Number(item.value);
        if (item.type === "second") map.second = Number(item.value);
    }
    if (map.year === undefined || map.month === undefined || map.day === undefined || map.hour === undefined || map.minute === undefined || map.second === undefined) {
        throw new Error(`Unable to resolve timezone parts for ${new Date(utcMs).toISOString()} in ${timeZone}`);
    }
    return map;
}
function isSameLocalTime(a, b) {
    return a.year === b.year && a.month === b.month && a.day === b.day && a.hour === b.hour && a.minute === b.minute && a.second === b.second;
}
function composeLocalDateTimeToUtcIso(localDate, localTime, timeZone = APP_TIME_ZONE) {
    if (!localDate || !localTime) {
        throw new Error("localDate and localTime are required");
    }
    const target = parseLocalDateTime(localDate, localTime);
    const targetUtcCandidateMs = Date.UTC(target.year, target.month - 1, target.day, target.hour, target.minute, target.second, 0);
    let utcMs = targetUtcCandidateMs;
    for(let tries = 0; tries < 4; tries += 1){
        const zoneParts = formatToPartsInTimeZone(utcMs, timeZone);
        const zonePartsUtcMs = Date.UTC(zoneParts.year, zoneParts.month - 1, zoneParts.day, zoneParts.hour, zoneParts.minute, zoneParts.second, 0);
        const offsetMs = zonePartsUtcMs - utcMs;
        const nextUtcMs = targetUtcCandidateMs - offsetMs;
        if (Math.abs(nextUtcMs - utcMs) < 1000) {
            utcMs = nextUtcMs;
            break;
        }
        utcMs = nextUtcMs;
    }
    const resultingParts = formatToPartsInTimeZone(utcMs, timeZone);
    if (!isSameLocalTime(resultingParts, target)) {
        throw new Error(`Local time ${localDate} ${localTime} does not exist in timezone ${timeZone} (DST gap?)`);
    }
    return new Date(utcMs).toISOString();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/patient/formatters/shared.formatters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatDate",
    ()=>formatDate,
    "formatDateTime",
    ()=>formatDateTime,
    "formatPlannedDateTime",
    ()=>formatPlannedDateTime,
    "formatPlannedSchedule",
    ()=>formatPlannedSchedule
]);
// Shared utilities used across multiple formatter modules
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$time$2f$date$2d$time$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-time/date-time.utils.ts [app-client] (ecmascript)");
;
function formatDate(date) {
    if (!date) return undefined;
    const d = new Date(date);
    if (isNaN(d.getTime())) return undefined;
    // timeZone: "UTC" is intentional — date-only strings (no time component)
    // are parsed as UTC midnight; without this, local offsets (e.g. UTC-3)
    // would shift the displayed date back by one day.
    const formatter = new Intl.DateTimeFormat("es-AR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        timeZone: "UTC"
    });
    return formatter.format(d);
}
function formatDateTime(date) {
    if (!date) return undefined;
    const d = new Date(date);
    if (isNaN(d.getTime())) return undefined;
    const hasTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$time$2f$date$2d$time$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasTimeComponent"])(date);
    const formatter = new Intl.DateTimeFormat("es-AR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        timeZone: hasTime ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$time$2f$date$2d$time$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["APP_TIME_ZONE"] : "UTC"
    });
    return formatter.format(d);
}
function formatPlannedDateTime(value) {
    if (!value) return undefined;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$time$2f$date$2d$time$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDateOnly"])(value)) {
        const formattedDate = formatDate(value);
        if (!formattedDate) return undefined;
        return `${formattedDate} • Sin horario definido`;
    }
    return formatDateTime(value);
}
function formatPlannedSchedule(plannedDate, plannedTime) {
    if (!plannedDate) {
        return {
            plannedDateLabel: undefined,
            plannedTimeLabel: undefined
        };
    }
    return {
        plannedDateLabel: formatDate(plannedDate) ?? plannedDate,
        plannedTimeLabel: plannedTime || "Sin horario definido"
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/patient/formatters/patient.formatters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Presentation utilities for Patient data (age & gender formatting).
 * Kept independent from FHIR/domain mapping — UI formatting only.
 */ __turbopack_context__.s([
    "computeAgeFromBirthDate",
    ()=>computeAgeFromBirthDate,
    "formatAddress",
    ()=>formatAddress,
    "formatAddressForGeocoding",
    ()=>formatAddressForGeocoding,
    "formatContactName",
    ()=>formatContactName,
    "formatDeceased",
    ()=>formatDeceased,
    "formatGenderToSpanish",
    ()=>formatGenderToSpanish,
    "formatMaritalStatus",
    ()=>formatMaritalStatus,
    "formatPatientName",
    ()=>formatPatientName,
    "formatRelationship",
    ()=>formatRelationship
]);
function computeAgeFromBirthDate(birthDate, now = new Date()) {
    if (!birthDate || typeof birthDate !== "string") return undefined;
    // Accepts FHIR date formats: YYYY | YYYY-MM | YYYY-MM-DD
    if (!/^\d{4}(-\d{2}(-\d{2})?)?$/.test(birthDate)) return undefined;
    const parts = birthDate.split("-");
    const year = parseInt(parts[0], 10);
    const month = parts[1] ? parseInt(parts[1], 10) : 1;
    const day = parts[2] ? parseInt(parts[2], 10) : 1;
    // Use UTC to avoid timezone side-effects when comparing dates
    const dob = new Date(Date.UTC(year, month - 1, day));
    if (isNaN(dob.getTime())) return undefined;
    const nowUtc = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
    let age = nowUtc.getUTCFullYear() - dob.getUTCFullYear();
    // Adjust if birthday has not occurred yet this year
    const dobMonth = dob.getUTCMonth();
    const dobDay = dob.getUTCDate();
    if (nowUtc.getUTCMonth() < dobMonth || nowUtc.getUTCMonth() === dobMonth && nowUtc.getUTCDate() < dobDay) {
        age -= 1;
    }
    if (age < 0) return undefined;
    return age === 1 ? `${age} año` : `${age} años`;
}
function formatGenderToSpanish(g) {
    if (!g || typeof g !== "string") {
        return "";
    }
    const key = g.toLowerCase().trim();
    let translated;
    switch(key){
        case "male":
            translated = "masculino";
            break;
        case "female":
            translated = "femenino";
            break;
        case "other":
            translated = "otro";
            break;
        case "unknown":
            translated = "desconocido";
            break;
        default:
            // cualquier valor inesperado se devuelve tal cual, capitalizado
            translated = key;
    }
    // capitaliza la primera letra y deja el resto como está
    return translated.charAt(0).toUpperCase() + translated.slice(1);
}
function formatDeceased(deceased) {
    if (deceased === true) return "Fallecido/a";
    if (typeof deceased === "string" && deceased.trim() !== "") {
        const d = new Date(deceased);
        if (!isNaN(d.getTime())) {
            // Force UTC timezone to avoid off-by-one-day errors when the
            // date string has no time component (parsed as UTC midnight).
            const formatter = new Intl.DateTimeFormat("es-ES", {
                year: "numeric",
                month: "long",
                day: "numeric",
                timeZone: "UTC"
            });
            return `Fallecido/a el ${formatter.format(d)}`;
        }
    }
    return undefined;
}
function formatMaritalStatus(status) {
    // The FHIR v3-MaritalStatus ValueSet (see https://terminology.hl7.org/3.1.0/ValueSet-v3-MaritalStatus.html)
    // contains both English words and one-letter codes. A HAPI server may return
    // either form or even free text with arbitrary casing, so we normalize input
    // and handle both possibilities. Unknown values fall back to "Desconocido".
    if (!status || typeof status !== "string") return "Desconocido";
    const key = status.trim().toLowerCase();
    switch(key){
        // --- English codes and values ------------------------------------------------
        case "married":
        case "m":
            return "Casado/a";
        case "single":
        case "s":
            return "Soltero/a";
        case "widowed":
        case "w":
            return "Viudo/a";
        case "divorced":
        case "d":
            return "Divorciado/a";
        case "separated":
        case "l":
            return "Separado/a legalmente";
        case "t":
            return "Pareja de hecho";
        case "u":
            return "Desconocido";
        // --- Spanish text -------------------------------------------------------------
        case "casado":
        case "casada":
            return "Casado/a";
        case "soltero":
        case "soltera":
            return "Soltero/a";
        case "viudo":
        case "viuda":
            return "Viudo/a";
        case "divorciado":
        case "divorciada":
            return "Divorciado/a";
        case "separado":
        case "separada":
            return "Separado/a legalmente";
        case "pareja de hecho":
        case "union libre":
            return "Pareja de hecho";
        case "soltero/a":
            return "Soltero/a";
        case "casado/a":
            return "Casado/a";
        case "viudo/a":
            return "Viudo/a";
        case "divorciado/a":
            return "Divorciado/a";
        case "separado/a legalmente":
            return "Separado/a legalmente";
        case "pareja de hecho":
            return "Pareja de hecho";
        default:
            // any other text (free-text or unrecognized code)
            return "Desconocido";
    }
}
function formatRelationship(code) {
    if (!code || typeof code !== "string") return "No registrada";
    const key = code.trim().toLowerCase();
    switch(key){
        case "c":
            return "Cónyuge";
        case "p":
            return "Padre/Madre";
        case "ch":
            return "Hijo/a";
        case "s":
            return "Hermano/a";
        case "o":
            return "Otro";
        // add more codes here as they appear in the real data
        default:
            // return the original string with first letter capitalized
            return key.charAt(0).toUpperCase() + key.slice(1);
    }
}
function formatContactName(name) {
    if (!name) return "Sin nombre";
    const givenStr = Array.isArray(name.given) ? name.given.join(" ") : name.given ?? "";
    const parts = [];
    if (givenStr.trim() !== "") parts.push(givenStr.trim());
    if (name.family && name.family.trim() !== "") parts.push(name.family.trim());
    if (parts.length === 0) return "Sin nombre";
    return parts.join(" ");
}
function formatPatientName(name) {
    return formatContactName(name);
}
function formatAddress(address) {
    if (!address) return "";
    const parts = [];
    if (Array.isArray(address.line) && address.line.length > 0) {
        parts.push(address.line.filter((l)=>l.trim() !== "").join(", "));
    }
    if (address.city) parts.push(address.city);
    if (address.postalCode) parts.push(`CP ${address.postalCode}`);
    return parts.join(", ");
}
function formatAddressForGeocoding(address) {
    if (!address) return "";
    const segments = [];
    if (Array.isArray(address.line) && address.line.length > 0) {
        const joined = address.line.filter((l)=>l.trim() !== "").join(", ");
        if (joined) segments.push(joined);
    }
    if (address.city) segments.push(address.city);
    // fixed province and country
    segments.push("Neuquén", "Argentina");
    return segments.filter((s)=>s && s.trim() !== "").join(", ");
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/patient/formatters/episode.formatters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatEpisodeType",
    ()=>formatEpisodeType,
    "formatReferralLine",
    ()=>formatReferralLine,
    "getSeverityBadge",
    ()=>getSeverityBadge,
    "translateEpisodeStatus",
    ()=>translateEpisodeStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$shared$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/shared.formatters.ts [app-client] (ecmascript)");
;
function translateEpisodeStatus(status) {
    switch(status){
        case "planned":
            return {
                label: "Planificado",
                colorClass: "bg-badge-info-bg text-badge-info-text"
            };
        case "waitlist":
            return {
                label: "En espera",
                colorClass: "bg-badge-warning-bg text-badge-warning-text"
            };
        case "active":
            return {
                label: "Activo",
                colorClass: "bg-badge-success-bg text-badge-success-text"
            };
        case "onhold":
            return {
                label: "En pausa",
                colorClass: "bg-badge-orange-bg text-badge-orange-text"
            };
        case "finished":
            return {
                label: "Finalizado",
                colorClass: "bg-badge-neutral-bg text-badge-neutral-text"
            };
        case "cancelled":
            return {
                label: "Cancelado",
                colorClass: "bg-badge-error-bg text-badge-error-text"
            };
        default:
            return {
                label: "Desconocido",
                colorClass: "bg-badge-neutral-bg text-badge-neutral-text"
            };
    }
}
function getSeverityBadge(sev) {
    if (!sev || sev.trim() === "") {
        return {
            label: "No registrada",
            colorClass: "bg-badge-neutral-bg text-badge-neutral-text"
        };
    }
    const lower = sev.toLowerCase();
    if (lower.includes("moder")) {
        return {
            label: "Moderada",
            colorClass: "bg-badge-warning-bg text-badge-warning-text"
        };
    }
    if (lower.includes("alto") || lower.includes("sever")) {
        return {
            label: "Severa",
            colorClass: "bg-badge-error-bg text-badge-error-text"
        };
    }
    if (lower.includes("leve") || lower.includes("mild")) {
        return {
            label: "Leve",
            colorClass: "bg-badge-success-bg text-badge-success-text"
        };
    }
    // fallback
    return {
        label: sev,
        colorClass: "bg-badge-neutral-bg text-badge-neutral-text"
    };
}
function formatEpisodeType(types) {
    if (!Array.isArray(types) || types.length === 0) {
        return "Sin tipo";
    }
    const labels = types.map((t)=>{
        switch(t){
            case "motora":
                return "Motor";
            case "respiratoria":
                return "Respiratorio";
            case "paliativa":
                return "Paliativo";
            default:
                // fallback for any unexpected future value, cast to string so
                // we can manipulate it safely without triggering never errors.
                const lower = t.toLowerCase();
                return lower[0].toUpperCase() + lower.slice(1);
        }
    });
    return labels.join(" + ");
}
function formatReferralLine(ref) {
    if (!ref) return "";
    const name = ref.practitionerName?.trim() ?? "";
    const dateFmt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$shared$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(ref.requestDate);
    if (name && dateFmt) return `${name} · ${dateFmt}`;
    if (name) return name;
    if (dateFmt) return dateFmt;
    return "";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/domain/assessments/eva-assessment.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EVA_RANGES",
    ()=>EVA_RANGES
]);
const EVA_RANGES = {
    mild: {
        min: 1,
        max: 3,
        label: "Leve"
    },
    moderate: {
        min: 4,
        max: 6,
        label: "Moderado"
    },
    severe: {
        min: 7,
        max: 9,
        label: "Intenso"
    },
    worst: {
        min: 10,
        max: 10,
        label: "Insoportable"
    },
    none: {
        min: 0,
        max: 0,
        label: "Sin dolor"
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/patient/formatters/clinical-ranges.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CLINICAL_RANGES",
    ()=>CLINICAL_RANGES,
    "getClinicalRanges",
    ()=>getClinicalRanges,
    "getClinicalZoneForValue",
    ()=>getClinicalZoneForValue,
    "getClinicalZones",
    ()=>getClinicalZones,
    "getEvaClinicalRanges",
    ()=>getEvaClinicalRanges
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/domain/assessments/eva-assessment.ts [app-client] (ecmascript)");
;
const CLINICAL_RANGES = {
    heartRate: {
        kind: "binary",
        normal: {
            min: 60,
            max: 100,
            label: "Normal",
            severity: "normal"
        },
        warning: [
            {
                min: 50,
                max: 59,
                label: "Alerta",
                severity: "warning"
            },
            {
                min: 101,
                max: 120,
                label: "Alerta",
                severity: "warning"
            }
        ],
        critical: [
            {
                min: Number.NEGATIVE_INFINITY,
                max: 49,
                label: "Crítico",
                severity: "critical"
            },
            {
                min: 121,
                max: Number.POSITIVE_INFINITY,
                label: "Crítico",
                severity: "critical"
            }
        ]
    },
    respiratoryRate: {
        kind: "binary",
        normal: {
            min: 12,
            max: 20,
            label: "Normal",
            severity: "normal"
        },
        warning: [
            {
                min: 10,
                max: 11,
                label: "Alerta",
                severity: "warning"
            },
            {
                min: 21,
                max: 25,
                label: "Alerta",
                severity: "warning"
            }
        ],
        critical: [
            {
                min: Number.NEGATIVE_INFINITY,
                max: 9,
                label: "Crítico",
                severity: "critical"
            },
            {
                min: 26,
                max: Number.POSITIVE_INFINITY,
                label: "Crítico",
                severity: "critical"
            }
        ]
    },
    oxygenSaturation: {
        kind: "binary",
        normal: {
            min: 95,
            max: Number.POSITIVE_INFINITY,
            label: "Normal",
            severity: "normal"
        },
        warning: [
            {
                min: 90,
                max: 94,
                label: "Alerta",
                severity: "warning"
            }
        ],
        critical: [
            {
                min: Number.NEGATIVE_INFINITY,
                max: 89,
                label: "Crítico",
                severity: "critical"
            }
        ]
    },
    bodyTemperature: {
        kind: "binary",
        normal: {
            min: 36.0,
            max: 37.4,
            label: "Normal",
            severity: "normal"
        },
        warning: [
            {
                min: 35.0,
                max: 35.9,
                label: "Alerta",
                severity: "warning"
            },
            {
                min: 37.5,
                max: 38.5,
                label: "Alerta",
                severity: "warning"
            }
        ],
        critical: [
            {
                min: Number.NEGATIVE_INFINITY,
                max: 34.9,
                label: "Crítico",
                severity: "critical"
            },
            {
                min: 38.6,
                max: Number.POSITIVE_INFINITY,
                label: "Crítico",
                severity: "critical"
            }
        ]
    },
    bloodPressure: {
        kind: "binary",
        normal: {
            min: 90,
            max: 139,
            label: "Normal",
            severity: "normal"
        },
        warning: [
            {
                min: 140,
                max: 159,
                label: "Alerta",
                severity: "warning"
            }
        ],
        critical: [
            {
                min: Number.NEGATIVE_INFINITY,
                max: 89,
                label: "Crítico",
                severity: "critical"
            },
            {
                min: 160,
                max: Number.POSITIVE_INFINITY,
                label: "Crítico",
                severity: "critical"
            }
        ]
    }
};
const VITAL_SIGN_RANGE_MAP = {
    "heart-rate": "heartRate",
    "respiratory-rate": "respiratoryRate",
    "oxygen-saturation": "oxygenSaturation",
    "body-temperature": "bodyTemperature",
    "blood-pressure": "bloodPressure"
};
function getClinicalRanges(type) {
    return CLINICAL_RANGES[VITAL_SIGN_RANGE_MAP[type]];
}
function getEvaClinicalRanges() {
    return {
        kind: "ordinal",
        zones: [
            {
                ...__TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].none,
                severity: "normal"
            },
            {
                ...__TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].mild,
                severity: "normal"
            },
            {
                ...__TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].moderate,
                severity: "warning"
            },
            {
                ...__TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].severe,
                severity: "critical"
            },
            {
                ...__TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].worst,
                severity: "critical"
            }
        ]
    };
}
function getClinicalZones(ranges) {
    if (ranges.kind === "ordinal") {
        return [
            ...ranges.zones
        ].sort((left, right)=>left.min - right.min);
    }
    return [
        ...ranges.critical ?? [],
        ...ranges.warning ?? [],
        ranges.normal
    ].sort((left, right)=>left.min - right.min);
}
function getClinicalZoneForValue(ranges, value) {
    return getClinicalZones(ranges).find((zone)=>value >= zone.min && value <= zone.max);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/patient/formatters/vital-sign.formatters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatVitalSignLabel",
    ()=>formatVitalSignLabel,
    "getBloodPressureBadge",
    ()=>getBloodPressureBadge,
    "getBloodPressureSingleValuePresentation",
    ()=>getBloodPressureSingleValuePresentation,
    "getClinicalStateAccentColor",
    ()=>getClinicalStateAccentColor,
    "getVitalSignBadge",
    ()=>getVitalSignBadge,
    "getVitalSignSingleValuePresentation",
    ()=>getVitalSignSingleValuePresentation,
    "groupVitalSignsByType",
    ()=>groupVitalSignsByType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$clinical$2d$ranges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/clinical-ranges.ts [app-client] (ecmascript)");
;
function getVitalSignBadge(type, value) {
    if (type === "blood-pressure") {
        // for blood pressure we return a neutral badge; the caller is
        // expected to invoke getBloodPressureBadge if more detailed
        // classification is desired.
        return {
            label: "Ver detalle",
            colorClass: "bg-badge-neutral-bg text-badge-neutral-text",
            severity: "normal"
        };
    }
    const zone = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$clinical$2d$ranges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClinicalZoneForValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$clinical$2d$ranges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClinicalRanges"])(type), value);
    switch(zone?.severity){
        case "normal":
            return {
                label: zone.label,
                colorClass: "bg-badge-success-bg text-badge-success-text",
                severity: "normal"
            };
        case "warning":
            return {
                label: zone.label,
                colorClass: "bg-badge-warning-bg text-badge-warning-text",
                severity: "warning"
            };
        case "critical":
            return {
                label: zone.label,
                colorClass: "bg-badge-error-bg text-badge-error-text",
                severity: "critical"
            };
        default:
            return {
                label: "Desconocido",
                colorClass: "bg-badge-neutral-bg text-badge-neutral-text",
                severity: "normal"
            };
    }
}
function getClinicalStateAccentColor(badge) {
    switch(badge.label){
        case "Normal":
        case "Sin dolor":
        case "Leve":
            return "var(--color-success)";
        case "Alerta":
        case "Moderado":
            return "#d97706";
        case "Crítico":
        case "Intenso":
        case "Insoportable":
            return "var(--color-error)";
        default:
            return "var(--color-muted)";
    }
}
function getVitalSignSingleValuePresentation(type, value) {
    const badge = getVitalSignBadge(type, value);
    return {
        badge,
        accentColor: getClinicalStateAccentColor(badge)
    };
}
function getBloodPressureSingleValuePresentation(systolic, diastolic) {
    const badge = getBloodPressureBadge(systolic, diastolic);
    return {
        badge,
        accentColor: getClinicalStateAccentColor(badge)
    };
}
function formatVitalSignLabel(type) {
    switch(type){
        case "heart-rate":
            return "Frecuencia cardíaca (lpm)";
        case "respiratory-rate":
            return "Frecuencia respiratoria (rpm)";
        case "oxygen-saturation":
            return "Saturación de oxígeno (%)";
        case "body-temperature":
            return "Temperatura (°C)";
        case "blood-pressure":
            return "Tensión arterial (mmHg)";
        default:
            return "";
    }
}
function groupVitalSignsByType(records) {
    const map = new Map();
    for (const rec of records){
        const { date } = rec;
        if (typeof rec.heartRate === "number") {
            const arr = map.get("heart-rate") || [];
            arr.push({
                date,
                value: rec.heartRate
            });
            map.set("heart-rate", arr);
        }
        if (typeof rec.respiratoryRate === "number") {
            const arr = map.get("respiratory-rate") || [];
            arr.push({
                date,
                value: rec.respiratoryRate
            });
            map.set("respiratory-rate", arr);
        }
        if (typeof rec.oxygenSaturation === "number") {
            const arr = map.get("oxygen-saturation") || [];
            arr.push({
                date,
                value: rec.oxygenSaturation
            });
            map.set("oxygen-saturation", arr);
        }
        if (typeof rec.bodyTemperature === "number") {
            const arr = map.get("body-temperature") || [];
            arr.push({
                date,
                value: rec.bodyTemperature
            });
            map.set("body-temperature", arr);
        }
        if (rec.bloodPressure && typeof rec.bloodPressure.systolic === "number" && typeof rec.bloodPressure.diastolic === "number") {
            const arr = map.get("blood-pressure") || [];
            arr.push({
                date,
                systolic: rec.bloodPressure.systolic,
                diastolic: rec.bloodPressure.diastolic
            });
            map.set("blood-pressure", arr);
        }
    }
    // ensure each array is sorted by date ascending for chart compatibility
    for (const arr of map.values()){
        arr.sort((a, b)=>a.date < b.date ? -1 : a.date > b.date ? 1 : 0);
    }
    return map;
}
function getBloodPressureBadge(systolic, _diastolic) {
    // diastolic value is currently unused; classification is based solely on
    // systolic pressure as a simplification.  Parameter kept for future use.
    void _diastolic;
    const zone = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$clinical$2d$ranges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClinicalZoneForValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$clinical$2d$ranges$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClinicalRanges"])("blood-pressure"), systolic);
    switch(zone?.severity){
        case "normal":
            return {
                label: zone.label,
                colorClass: "bg-badge-success-bg text-badge-success-text",
                severity: "normal"
            };
        case "warning":
            return {
                label: zone.label,
                colorClass: "bg-badge-warning-bg text-badge-warning-text",
                severity: "warning"
            };
        case "critical":
            return {
                label: zone.label,
                colorClass: "bg-badge-error-bg text-badge-error-text",
                severity: "critical"
            };
        default:
            return {
                label: "Desconocido",
                colorClass: "bg-badge-neutral-bg text-badge-neutral-text",
                severity: "normal"
            };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/fhir/systems.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Single source of truth for all custom FHIR system URIs used in the project.
 *
 * Centralizing these constants helps avoid typos and ensures consistency when
 * referring to domain-specific coding systems across the codebase.
 */ __turbopack_context__.s([
    "CLINICAL_NOTE_EXTENSION_URL",
    ()=>CLINICAL_NOTE_EXTENSION_URL,
    "PROCEDURE_SYSTEM",
    ()=>PROCEDURE_SYSTEM
]);
const PROCEDURE_SYSTEM = "http://kinesiologia-domiciliaria.local/procedimientos";
const CLINICAL_NOTE_EXTENSION_URL = "http://kinesiologia-domiciliaria.local/clinical-note";
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/infrastructure/fhir/mappers/shared/extract-helpers.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Extracts the last segment from a FHIR reference in the form "ResourceType/id".
 * Returns an empty string when the input is not a string or does not contain '/'.
 */ __turbopack_context__.s([
    "extractDate",
    ()=>extractDate,
    "extractEncounterId",
    ()=>extractEncounterId,
    "extractId",
    ()=>extractId,
    "extractPatientId",
    ()=>extractPatientId,
    "extractPerformer",
    ()=>extractPerformer
]);
function extractId(ref) {
    if (typeof ref !== "string" || !ref.includes("/")) return "";
    const parts = ref.split("/");
    return parts[parts.length - 1] || "";
}
const extractPatientId = extractId;
const extractEncounterId = extractId;
function extractPerformer(performer) {
    if (!Array.isArray(performer) || performer.length === 0) return;
    const first = performer[0];
    if (typeof first?.reference !== "string") return;
    return {
        id: extractId(first.reference),
        display: typeof first.display === "string" ? first.display : ""
    };
}
function extractDate(effectiveDateTime, issued) {
    if (typeof effectiveDateTime === "string" && effectiveDateTime.trim() !== "") {
        return effectiveDateTime;
    }
    if (typeof issued === "string" && issued.trim() !== "") {
        return issued;
    }
    return "";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/infrastructure/fhir/mappers/procedure.mapper.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mapFhirProcedureToDomain",
    ()=>mapFhirProcedureToDomain,
    "mapProcedureCode",
    ()=>mapProcedureCode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fhir$2f$systems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/fhir/systems.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$fhir$2f$mappers$2f$shared$2f$extract$2d$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/infrastructure/fhir/mappers/shared/extract-helpers.ts [app-client] (ecmascript)");
;
;
/**
 * Translate a raw FHIR status string into the domain union. Unknown values
 * default to `completed` which is a safe non-error fallback for procedures.
 */ function mapStatus(s) {
    switch(s){
        case "completed":
        case "in-progress":
        case "not-done":
            return s;
        default:
            return "completed";
    }
}
function mapProcedureCode(system, code) {
    if (system !== __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fhir$2f$systems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROCEDURE_SYSTEM"] || !code) return null;
    switch(code){
        // terapia-manual
        case "masoterapia":
            return {
                category: "terapia-manual",
                code: "masoterapia",
                display: "Masoterapia"
            };
        case "liberacion-miofascial":
            return {
                category: "terapia-manual",
                code: "liberacion-miofascial",
                display: "Liberación miofascial"
            };
        case "movilizacion-articular-pasiva":
            return {
                category: "terapia-manual",
                code: "movilizacion-articular-pasiva",
                display: "Movilización articular pasiva"
            };
        case "movilizacion-articular-activa-asistida":
            return {
                category: "terapia-manual",
                code: "movilizacion-articular-activa-asistida",
                display: "Movilización articular activa asistida"
            };
        case "manipulacion-articular":
            return {
                category: "terapia-manual",
                code: "manipulacion-articular",
                display: "Manipulación articular"
            };
        case "estiramiento-muscular":
            return {
                category: "terapia-manual",
                code: "estiramiento-muscular",
                display: "Estiramientos musculares"
            };
        case "inhibicion-muscular":
            return {
                category: "terapia-manual",
                code: "inhibicion-muscular",
                display: "Técnicas de inhibición muscular"
            };
        case "puntos-gatillo":
            return {
                category: "terapia-manual",
                code: "puntos-gatillo",
                display: "Puntos gatillo"
            };
        case "traccion-manual":
            return {
                category: "terapia-manual",
                code: "traccion-manual",
                display: "Tracción manual"
            };
        case "drenaje-linfatico":
            return {
                category: "terapia-manual",
                code: "drenaje-linfatico",
                display: "Drenaje linfático"
            };
        // ejercicio-terapeutico
        case "fortalecimiento":
            return {
                category: "ejercicio-terapeutico",
                code: "fortalecimiento",
                display: "Ejercicios de fortalecimiento"
            };
        case "resistencia-muscular":
            return {
                category: "ejercicio-terapeutico",
                code: "resistencia-muscular",
                display: "Ejercicios de resistencia muscular"
            };
        case "movilidad-articular-activa":
            return {
                category: "ejercicio-terapeutico",
                code: "movilidad-articular-activa",
                display: "Movilidad articular activa"
            };
        case "coordinacion":
            return {
                category: "ejercicio-terapeutico",
                code: "coordinacion",
                display: "Ejercicios de coordinación"
            };
        case "equilibrio":
            return {
                category: "ejercicio-terapeutico",
                code: "equilibrio",
                display: "Ejercicios de equilibrio"
            };
        case "reeducacion-marcha":
            return {
                category: "ejercicio-terapeutico",
                code: "reeducacion-marcha",
                display: "Reeducación de la marcha"
            };
        case "entrenamiento-funcional":
            return {
                category: "ejercicio-terapeutico",
                code: "entrenamiento-funcional",
                display: "Entrenamiento funcional"
            };
        case "entrenamiento-propioceptivo":
            return {
                category: "ejercicio-terapeutico",
                code: "entrenamiento-propioceptivo",
                display: "Entrenamiento propioceptivo"
            };
        case "ejercicios-bandas-elasticas":
            return {
                category: "ejercicio-terapeutico",
                code: "ejercicios-bandas-elasticas",
                display: "Ejercicios con bandas elásticas"
            };
        case "ejercicios-peso-corporal":
            return {
                category: "ejercicio-terapeutico",
                code: "ejercicios-peso-corporal",
                display: "Ejercicios con peso corporal"
            };
        case "rango-movimiento-rom":
            return {
                category: "ejercicio-terapeutico",
                code: "rango-movimiento-rom",
                display: "Rango de movimiento (ROM)"
            };
        case "ejercicios-linfokineticos":
            return {
                category: "ejercicio-terapeutico",
                code: "ejercicios-linfokineticos",
                display: "Ejercicios linfoquinéticos"
            };
        // rehabilitacion-neurologica
        case "facilitacion-neuromuscular-pnf":
            return {
                category: "rehabilitacion-neurologica",
                code: "facilitacion-neuromuscular-pnf",
                display: "Facilitación neuromuscular (PNF)"
            };
        case "control-postural":
            return {
                category: "rehabilitacion-neurologica",
                code: "control-postural",
                display: "Control postural"
            };
        case "reeducacion-motora":
            return {
                category: "rehabilitacion-neurologica",
                code: "reeducacion-motora",
                display: "Reeducación motora"
            };
        case "entrenamiento-avd":
            return {
                category: "rehabilitacion-neurologica",
                code: "entrenamiento-avd",
                display: "Entrenamiento de AVD"
            };
        case "reeducacion-equilibrio":
            return {
                category: "rehabilitacion-neurologica",
                code: "reeducacion-equilibrio",
                display: "Reeducación del equilibrio"
            };
        case "entrenamiento-transferencias":
            return {
                category: "rehabilitacion-neurologica",
                code: "entrenamiento-transferencias",
                display: "Entrenamiento de transferencias"
            };
        // rehabilitacion-respiratoria
        case "ejercicios-respiratorios":
            return {
                category: "rehabilitacion-respiratoria",
                code: "ejercicios-respiratorios",
                display: "Ejercicios respiratorios"
            };
        case "entrenamiento-muscular-respiratorio":
            return {
                category: "rehabilitacion-respiratoria",
                code: "entrenamiento-muscular-respiratorio",
                display: "Entrenamiento muscular respiratorio"
            };
        case "ventilacion-dirigida":
            return {
                category: "rehabilitacion-respiratoria",
                code: "ventilacion-dirigida",
                display: "Ventilación dirigida"
            };
        case "drenaje-bronquial":
            return {
                category: "rehabilitacion-respiratoria",
                code: "drenaje-bronquial",
                display: "Drenaje bronquial"
            };
        case "drenaje-postural":
            return {
                category: "rehabilitacion-respiratoria",
                code: "drenaje-postural",
                display: "Drenaje postural"
            };
        case "percusion-toracica":
            return {
                category: "rehabilitacion-respiratoria",
                code: "percusion-toracica",
                display: "Percusión torácica"
            };
        case "vibracion-toracica":
            return {
                category: "rehabilitacion-respiratoria",
                code: "vibracion-toracica",
                display: "Vibración torácica"
            };
        case "expansion-pulmonar-dirigida":
            return {
                category: "rehabilitacion-respiratoria",
                code: "expansion-pulmonar-dirigida",
                display: "Expansión pulmonar dirigida"
            };
        case "espiracion-lenta-prolongada":
            return {
                category: "rehabilitacion-respiratoria",
                code: "espiracion-lenta-prolongada",
                display: "Espiración lenta prolongada"
            };
        case "tos-asistida":
            return {
                category: "rehabilitacion-respiratoria",
                code: "tos-asistida",
                display: "Tos asistida"
            };
        case "espirometro-incentivo":
            return {
                category: "rehabilitacion-respiratoria",
                code: "espirometro-incentivo",
                display: "Espirómetro incentivo"
            };
        // fisioterapia
        case "laser":
            return {
                category: "fisioterapia",
                code: "laser",
                display: "Láser terapéutico"
            };
        case "onda-corta":
            return {
                category: "fisioterapia",
                code: "onda-corta",
                display: "Onda corta"
            };
        case "ultrasonido-terapeutico":
            return {
                category: "fisioterapia",
                code: "ultrasonido-terapeutico",
                display: "Ultrasonido terapéutico"
            };
        case "electroestimulacion-nmes":
            return {
                category: "fisioterapia",
                code: "electroestimulacion-nmes",
                display: "Electroestimulación muscular (NMES)"
            };
        case "corrientes-interferenciales":
            return {
                category: "fisioterapia",
                code: "corrientes-interferenciales",
                display: "Corrientes interferenciales"
            };
        case "electroanalgesia":
            return {
                category: "fisioterapia",
                code: "electroanalgesia",
                display: "Electroanalgesia"
            };
        case "crioterapia":
            return {
                category: "fisioterapia",
                code: "crioterapia",
                display: "Crioterapia"
            };
        case "termoterapia":
            return {
                category: "fisioterapia",
                code: "termoterapia",
                display: "Termoterapia"
            };
        case "magnetoterapia":
            return {
                category: "fisioterapia",
                code: "magnetoterapia",
                display: "Magnetoterapia"
            };
        // terapias-complementarias
        case "vendaje-neuromuscular":
            return {
                category: "terapias-complementarias",
                code: "vendaje-neuromuscular",
                display: "Vendaje neuromuscular (Kinesiotaping)"
            };
        case "vendaje-funcional":
            return {
                category: "terapias-complementarias",
                code: "vendaje-funcional",
                display: "Vendaje funcional"
            };
        case "compresion-elastica":
            return {
                category: "terapias-complementarias",
                code: "compresion-elastica",
                display: "Compresión elástica"
            };
        // educacion
        case "educacion-paciente":
            return {
                category: "educacion",
                code: "educacion-paciente",
                display: "Educación al paciente"
            };
        case "educacion-cuidador":
            return {
                category: "educacion",
                code: "educacion-cuidador",
                display: "Educación al cuidador"
            };
        case "uso-ayudas-tecnicas":
            return {
                category: "educacion",
                code: "uso-ayudas-tecnicas",
                display: "Entrenamiento en uso de ayudas técnicas"
            };
        case "prevencion-caidas":
            return {
                category: "educacion",
                code: "prevencion-caidas",
                display: "Prevención de caídas"
            };
        case "ergonomia-higiene-postural":
            return {
                category: "educacion",
                code: "ergonomia-higiene-postural",
                display: "Ergonomía e higiene postural"
            };
        default:
            return null;
    }
}
function mapFhirProcedureToDomain(resource) {
    const status = mapStatus(resource.status);
    const id = resource.id;
    const encounterId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$fhir$2f$mappers$2f$shared$2f$extract$2d$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractId"])(resource.encounter?.reference);
    const patientId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$fhir$2f$mappers$2f$shared$2f$extract$2d$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractId"])(resource.subject?.reference);
    // code mapping
    let category;
    let procedureCode;
    let display;
    if (resource.code?.coding && Array.isArray(resource.code.coding) && resource.code.coding.length > 0) {
        const mapped = mapProcedureCode(resource.code.coding[0].system, resource.code.coding[0].code);
        if (!mapped) return null;
        category = mapped.category;
        procedureCode = mapped.code;
        display = mapped.display;
    } else {
        return null;
    }
    const bodySite = Array.isArray(resource.bodySite) && resource.bodySite.length > 0 ? resource.bodySite[0].text || "" : undefined;
    let performerId;
    let performerName;
    if (Array.isArray(resource.performer) && resource.performer.length > 0 && resource.performer[0].actor) {
        performerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$fhir$2f$mappers$2f$shared$2f$extract$2d$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractId"])(resource.performer[0].actor.reference);
        performerName = resource.performer[0].actor.display || undefined;
    }
    const note = Array.isArray(resource.note) && resource.note.length > 0 ? resource.note[0].text || undefined : undefined;
    return {
        id,
        encounterId,
        patientId,
        status,
        category,
        code: procedureCode,
        display,
        bodySite,
        performerId,
        performerName,
        note
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/patient/formatters/procedure.formatters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatProcedureCategory",
    ()=>formatProcedureCategory,
    "formatProcedureCode",
    ()=>formatProcedureCode,
    "getProcedureStatusBadge",
    ()=>getProcedureStatusBadge,
    "groupProceduresByCategory",
    ()=>groupProceduresByCategory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fhir$2f$systems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/fhir/systems.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$fhir$2f$mappers$2f$procedure$2e$mapper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/infrastructure/fhir/mappers/procedure.mapper.ts [app-client] (ecmascript)");
;
;
function formatProcedureCategory(category) {
    switch(category){
        case "terapia-manual":
            return "Terapia manual";
        case "ejercicio-terapeutico":
            return "Ejercicio terapéutico";
        case "rehabilitacion-neurologica":
            return "Rehabilitación neurológica";
        case "rehabilitacion-respiratoria":
            return "Rehabilitación respiratoria";
        case "fisioterapia":
            return "Fisioterapia";
        case "terapias-complementarias":
            return "Terapias complementarias";
        case "educacion":
            return "Educación";
        default:
            // Should be impossible due to the union type, but satisfy TS
            return category;
    }
}
function formatProcedureCode(code) {
    const procedure = (0, __TURBOPACK__imported__module__$5b$project$5d2f$infrastructure$2f$fhir$2f$mappers$2f$procedure$2e$mapper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mapProcedureCode"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fhir$2f$systems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROCEDURE_SYSTEM"], code);
    if (!procedure) {
        return code;
    }
    return procedure.display;
}
function getProcedureStatusBadge(status) {
    switch(status){
        case "completed":
            return {
                label: "Realizado",
                colorClass: "bg-badge-success-bg text-badge-success-text"
            };
        case "in-progress":
            return {
                label: "En curso",
                colorClass: "bg-primary/10 text-primary"
            };
        case "not-done":
            return {
                label: "No realizado",
                colorClass: "bg-badge-neutral-bg text-badge-neutral-text"
            };
        default:
            // Exhaustive switch; TS will error if a case is missing.
            return {
                label: "Desconocido",
                colorClass: "bg-badge-neutral-bg text-badge-neutral-text"
            };
    }
}
function groupProceduresByCategory(procedures) {
    const map = new Map();
    for (const proc of procedures){
        const arr = map.get(proc.category) || [];
        arr.push(proc);
        map.set(proc.category, arr);
    }
    return map;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/patient/formatters/encounter-charts.formatters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CLINICAL_CHART_COLORS",
    ()=>CLINICAL_CHART_COLORS,
    "CLINICAL_CHART_RANGES",
    ()=>CLINICAL_CHART_RANGES,
    "adaptClinicalRangesToChartReferences",
    ()=>adaptClinicalRangesToChartReferences,
    "formatChartDate",
    ()=>formatChartDate,
    "formatEvaForChart",
    ()=>formatEvaForChart,
    "formatVitalSignsForChart",
    ()=>formatVitalSignsForChart
]);
const CLINICAL_CHART_RANGES = {
    heartRate: {
        min: 30,
        max: 220
    },
    respiratoryRate: {
        min: 5,
        max: 60
    },
    oxygenSaturation: {
        min: 50,
        max: 100
    },
    bodyTemperature: {
        min: 30.0,
        max: 43.0
    },
    bloodPressure: {
        min: 40,
        max: 280
    },
    eva: {
        min: 0,
        max: 10
    }
};
const CLINICAL_CHART_COLORS = {
    normal: "#16a34a",
    alert: "#d97706",
    critical: "#dc2626",
    neutral: "#6b7280",
    heartRate: "#2563eb",
    respiratoryRate: "#16a34a",
    oxygenSaturation: "#0891b2",
    bodyTemperature: "#d97706",
    systolic: "#ff6b6b",
    diastolic: "#4c87d9",
    painLow: "#16a34a",
    painModerate: "#d97706",
    painHigh: "#dc2626"
};
function getClinicalChartColor(severity) {
    switch(severity){
        case "normal":
            return CLINICAL_CHART_COLORS.normal;
        case "warning":
            return CLINICAL_CHART_COLORS.alert;
        case "critical":
            return CLINICAL_CHART_COLORS.critical;
    }
}
function adaptClinicalRangesToChartReferences(ranges, options = {}) {
    const zones = ranges.kind === "ordinal" ? ranges.zones : [
        ...ranges.critical ?? [],
        ...ranges.warning ?? [],
        ranges.normal
    ];
    const normalZones = zones.filter((zone)=>zone.severity === "normal");
    const includeNormalRange = options.includeNormalRange ?? normalZones.length > 0;
    const includeNormalReferenceZones = options.includeNormalReferenceZones ?? false;
    const clampToDomain = options.clampToDomain;
    const clamp = (value)=>{
        if (!clampToDomain) {
            return value;
        }
        return Math.min(Math.max(value, clampToDomain.min), clampToDomain.max);
    };
    const toChartZone = (zone)=>{
        const y1 = clamp(zone.min);
        const y2 = clamp(zone.max);
        if (y1 > y2) {
            return undefined;
        }
        return {
            y1,
            y2,
            fill: getClinicalChartColor(zone.severity)
        };
    };
    return {
        normalRange: includeNormalRange && normalZones.length > 0 ? {
            y1: clamp(Math.min(...normalZones.map((zone)=>zone.min))),
            y2: clamp(Math.max(...normalZones.map((zone)=>zone.max)))
        } : undefined,
        referenceZones: zones.filter((zone)=>includeNormalReferenceZones || zone.severity !== "normal").sort((left, right)=>left.min - right.min).map(toChartZone).filter((zone)=>zone !== undefined)
    };
}
function formatVitalSignsForChart(records) {
    const result = {
        heartRate: [],
        respiratoryRate: [],
        oxygenSaturation: [],
        bodyTemperature: [],
        bloodPressure: []
    };
    for (const rec of records){
        if (typeof rec.heartRate === "number") {
            result.heartRate.push({
                date: rec.date,
                value: rec.heartRate
            });
        }
        if (typeof rec.respiratoryRate === "number") {
            result.respiratoryRate.push({
                date: rec.date,
                value: rec.respiratoryRate
            });
        }
        if (typeof rec.oxygenSaturation === "number") {
            result.oxygenSaturation.push({
                date: rec.date,
                value: rec.oxygenSaturation
            });
        }
        if (typeof rec.bodyTemperature === "number") {
            result.bodyTemperature.push({
                date: rec.date,
                value: rec.bodyTemperature
            });
        }
        if (rec.bloodPressure && typeof rec.bloodPressure.systolic === "number" && typeof rec.bloodPressure.diastolic === "number") {
            result.bloodPressure.push({
                date: rec.date,
                systolic: rec.bloodPressure.systolic,
                diastolic: rec.bloodPressure.diastolic
            });
        }
    }
    const sortByDate = (arr)=>{
        arr.sort((a, b)=>a.date < b.date ? -1 : a.date > b.date ? 1 : 0);
    };
    sortByDate(result.heartRate);
    sortByDate(result.respiratoryRate);
    sortByDate(result.oxygenSaturation);
    sortByDate(result.bodyTemperature);
    sortByDate(result.bloodPressure);
    return result;
}
function formatEvaForChart(records) {
    const out = records.map((r)=>({
            date: r.date,
            value: r.score
        }));
    out.sort((a, b)=>a.date < b.date ? -1 : a.date > b.date ? 1 : 0);
    return out;
}
function formatChartDate(dateStr) {
    if (!dateStr) return "";
    const d = new Date(dateStr);
    if (Number.isNaN(d.getTime())) return "";
    const hasTimePrecision = dateStr.includes("T");
    return new Intl.DateTimeFormat("es-AR", {
        day: "2-digit",
        month: "2-digit",
        ...hasTimePrecision ? {
            hour: "2-digit",
            minute: "2-digit"
        } : {},
        timeZone: "UTC"
    }).format(d);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/patient/formatters/assessments/eva-assessment.formatters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatEvaScore",
    ()=>formatEvaScore,
    "getEvaBadge",
    ()=>getEvaBadge,
    "getEvaTrend",
    ()=>getEvaTrend,
    "getLatestEva",
    ()=>getLatestEva
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/domain/assessments/eva-assessment.ts [app-client] (ecmascript)");
;
function getEvaBadge(score) {
    if (score === __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].none.min) {
        return {
            label: __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].none.label,
            colorClass: "bg-badge-success-bg text-badge-success-text"
        };
    }
    if (score >= __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].mild.min && score <= __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].mild.max) {
        return {
            label: __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].mild.label,
            colorClass: "bg-badge-success-bg text-badge-success-text"
        };
    }
    if (score >= __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].moderate.min && score <= __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].moderate.max) {
        return {
            label: __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].moderate.label,
            colorClass: "bg-badge-warning-bg text-badge-warning-text"
        };
    }
    if (score >= __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].severe.min && score <= __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].severe.max) {
        return {
            label: __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].severe.label,
            colorClass: "bg-badge-error-bg text-badge-error-text"
        };
    }
    if (score === __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].worst.min && score === __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].worst.max) {
        return {
            label: __TURBOPACK__imported__module__$5b$project$5d2f$domain$2f$assessments$2f$eva$2d$assessment$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EVA_RANGES"].worst.label,
            colorClass: "bg-badge-error-bg text-badge-error-text"
        };
    }
    return {
        label: "Desconocido",
        colorClass: "bg-badge-neutral-bg text-badge-neutral-text"
    };
}
function formatEvaScore(score) {
    return `${score} / 10`;
}
function getLatestEva(records) {
    return records.length > 0 ? records[0] : null;
}
function getEvaTrend(records) {
    if (records.length < 2) return "sin-datos";
    const diff = records[0].score - records[1].score;
    if (diff < 0) return "mejora";
    if (diff > 0) return "empeora";
    return "estable";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/patient/formatters/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$shared$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/shared.formatters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$patient$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/patient.formatters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$episode$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/episode.formatters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$vital$2d$sign$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/vital-sign.formatters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$procedure$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/procedure.formatters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$encounter$2d$charts$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/encounter-charts.formatters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$assessments$2f$eva$2d$assessment$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/assessments/eva-assessment.formatters.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/patient/formatters.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatEpisodeStartLabel",
    ()=>formatEpisodeStartLabel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/patient/formatters/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/patient/formatters.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$shared$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/shared.formatters.ts [app-client] (ecmascript)");
;
;
function formatEpisodeStartLabel(startDate, status) {
    const fd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$shared$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(startDate) ?? "";
    switch(status){
        case "active":
            return `Activo desde ${fd}`;
        case "finished":
            return `Finalizado el ${fd}`;
        case "planned":
            return `Planificado para ${fd}`;
        default:
            return fd;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PlanOfCareView",
    ()=>PlanOfCareView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/patient/formatters.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$shared$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/shared.formatters.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function getPlanStatusBadge(status) {
    switch(status){
        case "draft":
            return {
                label: "Borrador",
                className: "bg-badge-warning-bg text-badge-warning-text"
            };
        case "active":
            return {
                label: "Activo",
                className: "bg-badge-success-bg text-badge-success-text"
            };
        case "completed":
            return {
                label: "Completado",
                className: "bg-badge-info-bg text-badge-info-text"
            };
        case "cancelled":
            return {
                label: "Revocado",
                className: "bg-badge-error-bg text-badge-error-text"
            };
        default:
            return {
                label: "Desconocido",
                className: "bg-badge-neutral-bg text-badge-neutral-text"
            };
    }
}
function getGoalStatusBadge(status) {
    switch(status){
        case "proposed":
            return {
                label: "Propuesto",
                className: "bg-badge-neutral-bg text-badge-neutral-text"
            };
        case "accepted":
            return {
                label: "Aceptado",
                className: "bg-badge-info-bg text-badge-info-text"
            };
        case "active":
            return {
                label: "Activo",
                className: "bg-badge-success-bg text-badge-success-text"
            };
        case "completed":
            return {
                label: "Completado",
                className: "bg-badge-success-bg text-badge-success-text"
            };
        case "cancelled":
            return {
                label: "Cancelado",
                className: "bg-badge-error-bg text-badge-error-text"
            };
        default:
            return {
                label: "Desconocido",
                className: "bg-badge-neutral-bg text-badge-neutral-text"
            };
    }
}
function getActivityStatusBadge(status) {
    switch(status){
        case "not-started":
            return {
                label: "Sin iniciar",
                className: "bg-badge-neutral-bg text-badge-neutral-text"
            };
        case "in-progress":
            return {
                label: "En curso",
                className: "bg-badge-info-bg text-badge-info-text"
            };
        case "completed":
            return {
                label: "Completado",
                className: "bg-badge-success-bg text-badge-success-text"
            };
        case "cancelled":
            return {
                label: "Cancelado",
                className: "bg-badge-error-bg text-badge-error-text"
            };
        default:
            return {
                label: "Desconocido",
                className: "bg-badge-neutral-bg text-badge-neutral-text"
            };
    }
}
function getCategoryLabel(category) {
    switch(category){
        case "short-term":
            return "Corto plazo";
        case "long-term":
            return "Largo plazo";
        default:
            return "";
    }
}
function PlanOfCareView({ plan }) {
    _s();
    const planBadge = getPlanStatusBadge(plan.status);
    const [activitiesExpanded, setActivitiesExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const periodStartLabel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$shared$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(plan.periodStart);
    const periodEndLabel = plan.periodEnd ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$shared$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(plan.periodEnd) : undefined;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "border border-border rounded-lg p-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-start justify-between gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs font-semibold uppercase tracking-wide text-muted",
                                children: "Plan de tratamiento"
                            }, void 0, false, {
                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                lineNumber: 145,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs text-foreground",
                                children: periodStartLabel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: [
                                        "Desde ",
                                        periodStartLabel,
                                        periodEndLabel ? ` · Hasta ${periodEndLabel}` : ""
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                    lineNumber: 150,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                lineNumber: 148,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                        lineNumber: 144,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-right",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${planBadge.className}`,
                                children: planBadge.label
                            }, void 0, false, {
                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                lineNumber: 158,
                                columnNumber: 11
                            }, this),
                            plan.authorName && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs text-muted mt-1",
                                children: [
                                    "por ",
                                    plan.authorName
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                lineNumber: 164,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                        lineNumber: 157,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                lineNumber: 143,
                columnNumber: 7
            }, this),
            plan.clinicalReasoning && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3 border-t border-border pt-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs font-semibold uppercase tracking-wide text-muted mb-1",
                        children: "Razonamiento clínico"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                        lineNumber: 171,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-2 border-primary pl-3 text-sm text-foreground italic",
                        children: plan.clinicalReasoning
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                        lineNumber: 174,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                lineNumber: 170,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3 border-t border-border pt-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs font-semibold uppercase tracking-wide text-muted mb-2",
                        children: "Objetivos"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                        lineNumber: 181,
                        columnNumber: 9
                    }, this),
                    plan.goals.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs text-muted italic",
                        children: "Sin objetivos registrados"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                        lineNumber: 185,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
                        children: plan.goals.map((goal)=>{
                            const badge = getGoalStatusBadge(goal.status);
                            const targetLabel = goal.targetDate ? ` · Fecha objetivo: ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$shared$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(goal.targetDate)}` : "";
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start justify-between gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm text-foreground",
                                                children: goal.description
                                            }, void 0, false, {
                                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                                lineNumber: 199,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.className}`,
                                                children: badge.label
                                            }, void 0, false, {
                                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                                lineNumber: 202,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                        lineNumber: 198,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-xs text-muted mt-1",
                                        children: [
                                            getCategoryLabel(goal.category),
                                            targetLabel
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                        lineNumber: 208,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, goal.id, true, {
                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                lineNumber: 197,
                                columnNumber: 17
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                        lineNumber: 189,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                lineNumber: 180,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3 border-t border-border pt-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs font-semibold uppercase tracking-wide text-muted",
                                children: [
                                    "Actividades planificadas (",
                                    plan.activities.length,
                                    ")"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                lineNumber: 221,
                                columnNumber: 11
                            }, this),
                            plan.activities.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "text-xs text-primary hover:underline",
                                onClick: ()=>setActivitiesExpanded((v)=>!v),
                                children: activitiesExpanded ? "Ocultar ▲" : "Ver todas ▼"
                            }, void 0, false, {
                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                lineNumber: 225,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                        lineNumber: 220,
                        columnNumber: 9
                    }, this),
                    plan.activities.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs text-muted italic mt-2",
                        children: "Sin actividades registradas"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                        lineNumber: 236,
                        columnNumber: 11
                    }, this) : activitiesExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2",
                        children: plan.activities.map((activity)=>{
                            const badge = getActivityStatusBadge(activity.status);
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start justify-between gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm text-foreground",
                                                children: activity.description
                                            }, void 0, false, {
                                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                                lineNumber: 247,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.className}`,
                                                children: badge.label
                                            }, void 0, false, {
                                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                                lineNumber: 250,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                        lineNumber: 246,
                                        columnNumber: 21
                                    }, this),
                                    typeof activity.frequencyPerWeek === "number" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-xs text-muted mt-1",
                                        children: [
                                            activity.frequencyPerWeek,
                                            "x por semana"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                        lineNumber: 257,
                                        columnNumber: 23
                                    }, this)
                                ]
                            }, activity.id, true, {
                                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                                lineNumber: 245,
                                columnNumber: 19
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                        lineNumber: 241,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
                lineNumber: 219,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/patients/[id]/components/plan-of-care/PlanOfCareView.tsx",
        lineNumber: 142,
        columnNumber: 5
    }, this);
}
_s(PlanOfCareView, "ww1Ve/+YeU7JcP/DOZm1tis8cOM=");
_c = PlanOfCareView;
var _c;
__turbopack_context__.k.register(_c, "PlanOfCareView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/patients/[id]/encounters/components/EncounterClinicalNote.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EncounterClinicalNote
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function EncounterClinicalNote({ note, collapsible = false, plannedStyle = false }) {
    _s();
    const [expanded, setExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const containerClass = plannedStyle ? "bg-blue-50 border border-blue-200 rounded-md p-3 text-sm text-foreground" : "bg-surface border border-border rounded-md p-3 text-sm text-foreground";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            plannedStyle ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs text-blue-700 font-semibold",
                children: "Nota del kinesiólogo"
            }, void 0, false, {
                fileName: "[project]/app/patients/[id]/encounters/components/EncounterClinicalNote.tsx",
                lineNumber: 25,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs font-semibold uppercase tracking-wide text-muted mb-1",
                children: "Nota clínica"
            }, void 0, false, {
                fileName: "[project]/app/patients/[id]/encounters/components/EncounterClinicalNote.tsx",
                lineNumber: 29,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: containerClass,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: !expanded && collapsible ? "line-clamp-3 overflow-hidden" : "",
                        children: note
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/encounters/components/EncounterClinicalNote.tsx",
                        lineNumber: 35,
                        columnNumber: 9
                    }, this),
                    collapsible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: "mt-1 text-xs text-primary hover:underline",
                        onClick: ()=>setExpanded((v)=>!v),
                        children: expanded ? "Ver menos" : "Ver más"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/encounters/components/EncounterClinicalNote.tsx",
                        lineNumber: 44,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/encounters/components/EncounterClinicalNote.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/patients/[id]/encounters/components/EncounterClinicalNote.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
}
_s(EncounterClinicalNote, "DuL5jiiQQFgbn7gBKAyxwS/H4Ek=");
_c = EncounterClinicalNote;
var _c;
__turbopack_context__.k.register(_c, "EncounterClinicalNote");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EvaThermometerCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$encounter$2d$charts$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/encounter-charts.formatters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$assessments$2f$eva$2d$assessment$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/patient/formatters/assessments/eva-assessment.formatters.ts [app-client] (ecmascript)");
"use client";
;
;
;
function EvaThermometerCard({ score }) {
    // ensure external callers can't push the bar outside 0–100%
    const boundedScore = Math.max(0, Math.min(10, score));
    // determine fill color based on the scale zones (use bounded value)
    const fillColor = boundedScore <= 3 ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$encounter$2d$charts$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLINICAL_CHART_COLORS"].normal : boundedScore <= 6 ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$encounter$2d$charts$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLINICAL_CHART_COLORS"].alert : __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$encounter$2d$charts$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CLINICAL_CHART_COLORS"].critical;
    const badge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$patient$2f$formatters$2f$assessments$2f$eva$2d$assessment$2e$formatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEvaBadge"])(boundedScore);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-lg shadow p-2 flex flex-row items-center gap-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-start",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs font-semibold text-muted",
                        children: "Dolor EVA"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx",
                        lineNumber: 28,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-lg font-bold text-foreground",
                        children: [
                            boundedScore,
                            " / 10"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx",
                        lineNumber: 29,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `mt-1 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.colorClass}`,
                        children: badge.label
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx",
                        lineNumber: 32,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-5 rounded-full overflow-hidden h-20 bg-gray-100",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute w-full h-[30%] bg-red-200 top-0"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute w.full h-[30%] bg-yellow-200 top-[30%]"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute w-full h-[40%] bg-green-200 top-[60%]"
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx",
                        lineNumber: 44,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-0 w-full rounded-full transition-all duration-500",
                        style: {
                            height: `${boundedScore * 10}%`,
                            backgroundColor: fillColor
                        }
                    }, void 0, false, {
                        fileName: "[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/patients/[id]/encounters/components/EvaThermometerCard.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_c = EvaThermometerCard;
var _c;
__turbopack_context__.k.register(_c, "EvaThermometerCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_d1d9a92a._.js.map