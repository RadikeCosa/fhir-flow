(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/breadcrumbs/breadcrumbs.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildBreadcrumbs",
    ()=>buildBreadcrumbs
]);
function buildBreadcrumbs(pathname, patientName) {
    const segments = pathname.split("/").filter(Boolean);
    const base = {
        label: "Pacientes",
        href: "/patients",
        current: false
    };
    // Exact list view
    if (pathname === "/patients") {
        return [
            {
                label: "Pacientes",
                current: true
            }
        ];
    }
    const crumbs = [
        base
    ];
    // /patients/{id}
    const patientId = segments[1];
    if (patientId) {
        const patientCrumb = {
            label: patientName ?? "Paciente",
            href: `/patients/${patientId}`,
            current: false
        };
        // If this is the last segment, it is current.
        if (segments.length === 2) {
            patientCrumb.current = true;
            // current crumb must not have an href
            patientCrumb.href = undefined;
        }
        crumbs.push(patientCrumb);
    }
    // /patients/{id}/{sub}
    const thirdSegment = segments[2];
    if (thirdSegment) {
        const label = (()=>{
            switch(thirdSegment){
                case "encounters":
                    return "Encuentros";
                case "vital-signs":
                    return "Signos vitales";
                case "assessments":
                    return "Evaluaciones";
                default:
                    return `${thirdSegment.charAt(0).toUpperCase()}${thirdSegment.slice(1)}`;
            }
        })();
        crumbs.push({
            label,
            current: true
        });
    }
    return crumbs;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/Breadcrumbs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Breadcrumbs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$breadcrumbs$2f$breadcrumbs$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/breadcrumbs/breadcrumbs.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function Breadcrumbs({ patientName }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const crumbs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$breadcrumbs$2f$breadcrumbs$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildBreadcrumbs"])(pathname, patientName);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        "aria-label": "Navegación de ubicación",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
            role: "list",
            className: "flex items-center gap-1 text-sm flex-wrap",
            children: crumbs.map((crumb, index)=>{
                const isLast = index === crumbs.length - 1;
                const content = crumb.href && !crumb.current ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: crumb.href,
                    className: "text-muted hover:text-foreground transition-colors",
                    children: crumb.label
                }, void 0, false, {
                    fileName: "[project]/app/components/Breadcrumbs.tsx",
                    lineNumber: 28,
                    columnNumber: 15
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-foreground font-medium",
                    "aria-current": crumb.current ? "page" : undefined,
                    children: crumb.label
                }, void 0, false, {
                    fileName: "[project]/app/components/Breadcrumbs.tsx",
                    lineNumber: 35,
                    columnNumber: 15
                }, this);
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    className: "flex items-center gap-1",
                    children: [
                        content,
                        !isLast ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "aria-hidden": "true",
                            className: "text-muted select-none",
                            children: "›"
                        }, void 0, false, {
                            fileName: "[project]/app/components/Breadcrumbs.tsx",
                            lineNumber: 50,
                            columnNumber: 17
                        }, this) : null
                    ]
                }, `${crumb.label}-${index}`, true, {
                    fileName: "[project]/app/components/Breadcrumbs.tsx",
                    lineNumber: 44,
                    columnNumber: 13
                }, this);
            })
        }, void 0, false, {
            fileName: "[project]/app/components/Breadcrumbs.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/Breadcrumbs.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_s(Breadcrumbs, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = Breadcrumbs;
var _c;
__turbopack_context__.k.register(_c, "Breadcrumbs");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_59a5c667._.js.map